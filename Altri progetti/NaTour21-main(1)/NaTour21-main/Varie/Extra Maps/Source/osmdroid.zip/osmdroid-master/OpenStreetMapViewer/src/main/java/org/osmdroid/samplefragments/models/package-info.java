/**
 * This package's purpose is to contain any support classes, data models, and utilities for the sample fragments
 */