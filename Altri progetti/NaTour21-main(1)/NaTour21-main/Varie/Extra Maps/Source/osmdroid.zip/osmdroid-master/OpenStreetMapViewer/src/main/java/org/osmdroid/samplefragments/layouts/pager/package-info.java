package org.osmdroid.samplefragments.layouts.pager; /**
 * This package's purpose is to demonstrate osmdroid in a view pager fragment
 */